#pragma warning(disable : 4018)
#pragma warning(disable : 4244)
#pragma warning(disable : 4996)
#pragma warning(disable : 4800)
#pragma warning(disable : 4312)

#include <UT/UT_DSOVersion.h>

#include <RE/RE_Render.h>

#include <GEO/GEO_Primitive.h>

#include <GU/GU_Detail.h>
#include <GU/GU_PrimGroupClosure.h>

#include <GR/GR_Detail.h>
#include <GR/GR_RenderHook.h>
#include <GR/GR_RenderTable.h>
#include <GR/GR_DisplayOption.h>


class GR_Fluid : public GR_RenderHook
{
public:
    GR_Fluid() {}
    virtual ~GR_Fluid() {}

	static int preview(const GU_Detail *gdp);

	int		 getWireMask(GU_Detail *gdp, const GR_DisplayOption * /*dopt*/) const {
		if (preview(gdp))
			return 0;
		else
			return GEOPRIMALL;
    }

    virtual void renderWire(GU_Detail *gdp,
			RE_Render &ren,
			const GR_AttribOffset &ptinfo,
			const GR_DisplayOption *dopt,
			float lod,
			const GU_PrimGroupClosure *hidden_geometry);

    int		 getShadedMask(GU_Detail *gdp, const GR_DisplayOption * /*dopt*/) const {
		if (preview(gdp))
			return 0;
		else
			return GEOPRIMALL;
    }

    virtual void renderShaded(GU_Detail *gdp,
			RE_Render &ren,
			const GR_AttribOffset &ptinfo,
			const GR_DisplayOption *dopt,
			float lod,
			const GU_PrimGroupClosure *hidden_geometry);

    virtual const char *getName() const { return "GR_Fluid"; }
};

int GR_Fluid::preview(const GU_Detail *gdp) {

	return 0;

}


void GR_Fluid::renderWire(GU_Detail *gdp,
		    RE_Render &ren,
		    const GR_AttribOffset & /*ptinfo*/,
		    const GR_DisplayOption *dopt,
		    float /*lod*/,
		    const GU_PrimGroupClosure * /*hidden_geometry*/)
{
  
}


void GR_Fluid::renderShaded(GU_Detail *gdp,
		    RE_Render &ren,
		    const GR_AttribOffset &ptinfo,
		    const GR_DisplayOption *dopt,
		    float lod,
		    const GU_PrimGroupClosure *hidden_geometry)
{
    // We use the wire render again...
    renderWire(gdp, ren, ptinfo, dopt, lod, hidden_geometry);
}

void newRenderHook(GR_RenderTable *table)
{
    GR_Fluid *hook = new GR_Fluid;
    
    table->addHook(hook, GR_RENDER_HOOK_VERSION);
}

