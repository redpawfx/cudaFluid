#include "vhFluidSolver.h"


int VHFluidSolver::numSolvers = 0;
VHFluidSolver* VHFluidSolver::solverList[10];

VHFluidSolver::VHFluidSolver() {

	numSolvers += 1;
	solverList[numSolvers] = this;
	id = numSolvers;

	f = 0;
	fps = 30;
	substeps = 1;
	jacIter = 50;

	fluidSize = cu::make_float2(10.0,10.0);
	res = cu::make_int2(-1,-1);

	borderPosX = 1;
	borderNegX = 1;
	borderPosY = 1;
	borderNegY = 1;

	densDis = 0.0;
	densBuoyStrength = 1; //1
	densBuoyDir = cu::make_float2(0.0,1.0);

	velDamp = 0.01;
	vortConf = 5.0; //5

	noiseStr = 1.0; //1.0
	noiseFreq = 1.0;
	noiseOct = 3;
	noiseLacun = 4.0;
	noiseSpeed = 0.01;
	noiseAmp = 0.5;

	emitters = new FluidEmitter[1];
	colliders = new Collider[1];

	nEmit = 1;
	emitters[0].amount = 1;
	emitters[0].posX = 0;
	emitters[0].posY = -4; //-4
	emitters[0].radius = 0.5;

	nColliders = 0;
	colliders[0].posX = 0;
	colliders[0].posY = 0;
	colliders[0].radius = 1;

	preview = 1;

}

VHFluidSolver::~VHFluidSolver() {

	numSolvers -= 1;

	if(res.x != -1) {
		delete host_dens;
		//delete host_vel;

	}

	clear2DFluid(this);

	delete emitters;
	delete colliders;

}

void VHFluidSolver::changeFluidRes(int x, int y){

	if(res.x != -1) {
		delete host_dens;
		//delete host_vel;
	}

	clear2DFluid(this);
	init2DFluid(this, x, y);

	host_dens = new float[res.x*res.y* sizeof(float)];
	//host_vel = new float[res.x*res.y* sizeof(float)*2];

}

void VHFluidSolver::initFluidSolver(int x, int y){

	init2DFluid(this, x, y);
}

void VHFluidSolver::solveFluid(){

	solve2DFluid(this);


}


void VHFluidSolver::resetFluid(){

	reset2DFluid(this);


}

void VHFluidSolver::renderFluid(cu::float4* d_output){

	render2DFluid(this, d_output);


}