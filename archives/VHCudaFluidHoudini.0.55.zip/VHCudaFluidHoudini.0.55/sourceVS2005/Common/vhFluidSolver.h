#ifndef __FLUID2D_H__
#define __FLUID2D_H__

#include "vhObjects.h"

namespace cu{
	#include <vector_functions.h>
}

typedef unsigned int  uint;
typedef unsigned char uchar;

struct VHFluidSolver {

	VHFluidSolver();
	~VHFluidSolver();

	static VHFluidSolver* solverList[10];
	static int numSolvers;

	int id;

	int preview;
	int previewType;
	float bounds;

	int f;
	int nEmit;
	FluidEmitter* emitters;

	int nColliders;
	Collider* colliders;

	int fps;
	int substeps;
	int jacIter;

	cu::int2 res;

	cu::float2 fluidSize;

	float densDis;
	float densBuoyStrength;
	cu::float2 densBuoyDir;

	float velDamp;
	float vortConf;

	float noiseStr;
	float noiseFreq;
	int noiseOct;
	float noiseLacun;
	float noiseSpeed;
	float noiseAmp;

	int colOutput;

	int borderPosX;
	int borderNegX;
	int borderPosY;
	int borderNegY;

	float			*host_dens;
	float			*host_vel;

	cu::float4		*output_display;

	float			*dev_noise;
	cu::float2          *dev_vel;
	float           *dev_dens;
	float           *dev_pressure;
	float           *dev_div;
	float           *dev_vort;
	cu::float4			*dev_obstacles;

	cu::cudaArray *noiseArray;
	cu::cudaArray *velArray;
	cu::cudaArray *densArray;
	cu::cudaArray *pressureArray;
	cu::cudaArray *divArray;
	cu::cudaArray *vortArray;
	cu::cudaArray *obstArray;


    //cudaEvent_t     start, stop;
    float           totalTime;
    float           frames;

	void changeFluidRes(int x, int y);
	void initFluidSolver(int x, int y);
	void solveFluid();
	void resetFluid();
	void renderFluid(cu::float4 *d_output);

	long domainSize( void ) const { return res.x * res.y * sizeof(float); }

};

extern "C" void init2DFluid(VHFluidSolver* fluidSolver, int dimX, int dimY);
extern "C" void clear2DFluid(VHFluidSolver* fluidSolver);
extern "C" void solve2DFluid(VHFluidSolver* fluidSolver);
extern "C" void reset2DFluid(VHFluidSolver* fluidSolver);
extern "C" void render2DFluid(VHFluidSolver* fluidSolver, cu::float4* d_output);

#endif  // __DATABLOCK_H__