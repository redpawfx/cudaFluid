#include "vhFluidSolver3D.h"


int VHFluidSolver3D::numSolvers = 0;
VHFluidSolver3D* VHFluidSolver3D::solverList[10];

VHFluidSolver3D::VHFluidSolver3D() {

	numSolvers += 1;
	solverList[numSolvers] = this;
	id = numSolvers;

	preview = 0;
	drawCube = 0;
	opaScale = 1;
	stepMul = 1;
	displayRes = 1;

	doShadows = 0;
	shadowDens = 1;
	shadowStepMul = 2;
	shadowThres = 1;

	displaySlice = 0;
	sliceType = 0;
	sliceAxis = 2;
	slicePos = 0.5;
	sliceBounds = 1;

	lightPos = cu::make_float3(10,10,0);

	f = 0;
	fps = 30;
	substeps = 1;
	jacIter = 50;

	fluidSize = cu::make_float3(10.0,10.0,10.0);

	res.width = -1;
	res.height = -1;
	res.depth = -1;
	
	borderPosX = 1;
	borderNegX = 1;
	borderPosY = 1;
	borderNegY = 1;
	borderPosZ = 1;
	borderNegZ = 1;

	densDis = 0.0;
	densBuoyStrength = 1; //1
	densBuoyDir = cu::make_float3(0.0,1.0,0.0);

	velDamp = 0.01;
	vortConf = 5.0; //5

	noiseStr = 0.0; //1.0
	noiseFreq = 1.0;
	noiseOct = 3;
	noiseLacun = 4.0;
	noiseSpeed = 0.01;
	noiseAmp = 0.5;

	emitters = new FluidEmitter[1];
	colliders = new Collider[1];

	nEmit = 1;
	emitters[0].amount = 1;
	emitters[0].posX = 0;
	emitters[0].posY = -4; //-4
	emitters[0].radius = 0.5;

	nColliders = 0;
	colliders[0].posX = 0;
	colliders[0].posY = 0;
	colliders[0].radius = 1;

}

VHFluidSolver3D::~VHFluidSolver3D() {
	numSolvers -= 1;

	if(res.width != -1) {
		delete host_dens;
		delete host_vel;

	}

	clear3DFluid(this);
	delete emitters;
	delete colliders;

}


void VHFluidSolver3D::changeFluidRes(int x, int y, int z){

	if(res.width != -1) {
		delete host_dens;
		delete host_vel;
	}

	clear3DFluid(this);
	init3DFluid(this, x, y, z);

	host_dens = new float[res.width*res.height*res.depth* sizeof(float)];
	host_vel = new float[res.width*res.height*res.depth* sizeof(float)*4];

}

void VHFluidSolver3D::initFluidSolver(int x, int y, int z){

	init3DFluid(this, x, y, z);
}

void VHFluidSolver3D::solveFluid(){

	solve3DFluid(this);


}


void VHFluidSolver3D::resetFluid(){

	reset3DFluid(this);


}

void VHFluidSolver3D::renderFluid(cu::float4 *d_output, uint imageW, uint imageH, float focalLength){

	render_kernel(this, d_output, imageW, imageH, focalLength);


}

void VHFluidSolver3D::renderSlice(cu::float4* d_output){

	renderFluidSlice(this, d_output);


}