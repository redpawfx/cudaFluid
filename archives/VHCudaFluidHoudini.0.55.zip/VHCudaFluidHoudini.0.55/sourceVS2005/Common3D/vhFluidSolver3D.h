#ifndef __FLUID3D_H__
#define __FLUID3D_H__

#include "vhObjects3D.h"

namespace cu{
	#include <vector_functions.h>
}

typedef unsigned int  uint;
typedef unsigned char uchar;


struct VHFluidSolver3D {

	VHFluidSolver3D();
	~VHFluidSolver3D();

	static VHFluidSolver3D* solverList[10];
	static int numSolvers;

	int id;

	int preview;
	int drawCube;
	float opaScale;
	float stepMul;
	int displayRes;

	int doShadows;
	float shadowDens;
	float shadowStepMul;
	float shadowThres;

	int displaySlice;
	int sliceType;
	int sliceAxis;
	float slicePos;
	float sliceBounds;

	int f;
	int nEmit;
	FluidEmitter* emitters;

	int nColliders;
	Collider* colliders;

	int fps;
	int substeps;
	int jacIter;
	
	cu::cudaExtent res;

	cu::float3 fluidSize;

	int borderNegX;
	int borderPosX;
	int borderNegY;
	int borderPosY;
	int borderNegZ;
	int borderPosZ;

	float densDis;
	float densBuoyStrength;
	cu::float3 densBuoyDir;

	float velDamp;
	float vortConf;

	float noiseStr;
	float noiseFreq;
	int noiseOct;
	float noiseLacun;
	float noiseSpeed;
	float noiseAmp;

	cu::float3 lightPos;

	int colOutput;

	float			*host_dens;
	float			*host_vel;

	cu::float4		*output_display;
	cu::float4		*output_display_slice;

	float			*dev_noise;
	cu::float4      *dev_vel;
	float			*dev_dens;
	float           *dev_pressure;
	float           *dev_div;
	cu::float4           *dev_vort;
	cu::float4		*dev_obstacles;

	cu::cudaArray *densArray;
	cu::cudaArray *noiseArray;
	cu::cudaArray *velArray;
	cu::cudaArray *divArray;
	cu::cudaArray *pressureArray;
	cu::cudaArray *obstaclesArray;
	cu::cudaArray *vortArray;

    float           totalTime;
    float           frames;

	void changeFluidRes(int x, int y, int z);
	void initFluidSolver(int x, int y, int z);
	void solveFluid();
	void resetFluid();
	void renderFluid(cu::float4 *d_output, uint imageW, uint imageH, float focalLength);
	void renderSlice(cu::float4* d_output);


	long domainSize( void ) const { return res.width * res.height * res.depth * sizeof(float); }

};

extern "C" void copyInvViewMatrix(float *invViewMatrix, size_t sizeofMatrix);
extern "C" void render_kernel(VHFluidSolver3D* fluidSolver, cu::float4 *d_output, uint imageW, uint imageH,
							  float focalLength);

extern "C" void init3DFluid(VHFluidSolver3D* fluidSolver, int dimX, int dimY, int dimZ);
extern "C" void clear3DFluid(VHFluidSolver3D* fluidSolver);
extern "C" void solve3DFluid(VHFluidSolver3D* fluidSolver);
extern "C" void reset3DFluid(VHFluidSolver3D* fluidSolver);
extern "C" void renderFluidSlice(VHFluidSolver3D* d, cu::float4* d_output);

#endif  // __DATABLOCK_H__