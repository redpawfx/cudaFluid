#pragma warning(disable : 4018)
#pragma warning(disable : 4244)
#pragma warning(disable : 4996)
#pragma warning(disable : 4800)
#pragma warning(disable : 4312)

//#include <GL/glew.h>

#include <UT/UT_DSOVersion.h>
#include <UT/UT_Interrupt.h>

#include <OP/OP_Operator.h>
#include <OP/OP_OperatorTable.h>

#include <RE/RE_Render.h>
#include <GR/GR_RenderHook.h>
#include <GR/GR_RenderTable.h>

#include "SOP_FluidSolver2D.h"
#include "SOP_FluidSolver3D.h"
#include "GR_Fluid.h"

void newSopOperator(OP_OperatorTable *table) {
    table->addOperator(
	    new OP_Operator("vhFluidSolver2D",			// Internal name
			    "CudaFluidSolver2D",			// UI name
			     SOP_FluidSolver2D::myConstructor,	// How to build the SOP
			     SOP_FluidSolver2D::myTemplateList,	// My parameters
			     0,				// Min # of sources
			     2,				// Max # of sources
			     0,
				 OP_FLAG_GENERATOR)		// Flag it as generator
	    );


	table->addOperator(
	    new OP_Operator("vhFluidSolver3D",			// Internal name
			    "CudaFluidSolver3D",			// UI name
			     SOP_FluidSolver3D::myConstructor,	// How to build the SOP
			     SOP_FluidSolver3D::myTemplateList,	// My parameters
			     0,				// Min # of sources
			     2,				// Max # of sources
			     0,
				 OP_FLAG_GENERATOR)		// Flag it as generator
	    );
}

void newRenderHook(GR_RenderTable *table)
{
    GR_Fluid *hook = new GR_Fluid;
    
    table->addHook(hook, GR_RENDER_HOOK_VERSION);
}