#include <vector_types.h>

namespace cu {

typedef float3 float3;
typedef float4 float4;
typedef cudaExtent cudaExtent;
typedef cudaArray cudaArray;


}